/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyek;

/**
 *
 * @kelompok 12
 */

public class Poin_pelanggaran {
   private String kode_pelanggaran;
   private String nama_pelanggaran;
   private String pengurangan_poin;
   private String jenis_pelanggaran;
   String tanggal_update;
   
   
   public Poin_pelanggaran(String _kode_pelanggaran, String _nama_pelanggaran, String _pengurangan_poin, String _jenis_pelanggaran, String _tanggal_update){
       this.kode_pelanggaran = kode_pelanggaran;
       this.nama_pelanggaran = nama_pelanggaran;
       this.pengurangan_poin = pengurangan_poin;
       this.jenis_pelanggaran = jenis_pelanggaran;
       this.tanggal_update = tanggal_update;
   }
   
   public void Insertkode_pelanggaran(){
       this.kode_pelanggaran = kode_pelanggaran;
   }
   
   public void Updatekode_pelanggaran(){
       this.kode_pelanggaran = kode_pelanggaran;
   }
   
   public String viewkode_pelanggaran(){
       return kode_pelanggaran;
   } 
   
   public void Insertnama_pelanggaran(){
       this.nama_pelanggaran = nama_pelanggaran;
   }
   
   public void Updatenama_pelanggaran(){
       this.nama_pelanggaran = nama_pelanggaran;
   }
   
   public String viewnama_pelanggaran(){
       return nama_pelanggaran;
   }
   
   public void Insertpengurangan_poin(){
       this.pengurangan_poin = pengurangan_poin;
   }
   
   public void Updatepengurangan_poin(){
       this.pengurangan_poin = pengurangan_poin;
   }
   
   public String viewpengurangan_poin(){
       return pengurangan_poin;
   }
   
   public void Insertjenis_pelanggaran(){
       this.jenis_pelanggaran = jenis_pelanggaran;
   }
   
   public void Updatejenis_pelanggaran(){
       this.jenis_pelanggaran = jenis_pelanggaran;
   }
   
   public String viewjenispelanggaran(){
       return jenis_pelanggaran;
   }
   
   public void Inserttanggal_update(){
       this.tanggal_update = tanggal_update;
   }
   
   public void Updatetanggal_update(){
       this.tanggal_update = tanggal_update;
   }
   
   public String viewtanggal_update(){
       return tanggal_update;
   }
}


/**
 *
 * @author 12S18000 - Novita Enjelia Hutapea
 * @author 12S18017 - Putri Yohana Panjaitan
 * @author 12S18036 - Sandraulina Siregar
 * @author 12S18050 - Elsa Elfransyah Marbun
 */

import java.util.Date;
public class Pelanggaran_Mahasiswa {
    public char NIM;
    public char kode_pelanggaran;
    private Date tanggal_point_ditambahkan;
    private int bobot_pelanggaran;

    
public void insert_pelanggara_mahasiswa(){
    this.kode_pelanggaran = kode_pelanggaran;
}

public void update_pelanggaran_mahasiswa(){
    this.bobot_pelanggaran = bobot_pelanggaran;
}
}

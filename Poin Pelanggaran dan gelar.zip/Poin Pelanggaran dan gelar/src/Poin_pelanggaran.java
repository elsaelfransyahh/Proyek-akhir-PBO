/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author 12S18009 – Novita Enjelia Hutapea  
 * @author 12S18017 – Putri Yohana Panjaitan 
 * @author 12S18036 - Sandraulina Siregar 
 * @author 12S18050 - Elsa Elfransyah Marbun 
 */

import java.util.Date;
public class Poin_pelanggaran {
     private char kode_pelanggaran;
     private char jenis_pelanggaran;
     private int bobot_pelanggaran;
     private Date tanggal_poin_pelanggaran;
     
     
     public void insert_poin_pelanggaran(){
     this.bobot_pelanggaran = bobot_pelanggaran; 
     }
     
     public void update_poin_pelanggaran(){
     this.bobot_pelanggaran = bobot_pelanggaran;
     }
     
     public void delete_poin_pelanggaran(){
      this.bobot_pelanggaran = bobot_pelanggaran;   
     }
     
     public char view_poin_pelanggaran(){
     return jenis_pelanggaran;
     }
     
}

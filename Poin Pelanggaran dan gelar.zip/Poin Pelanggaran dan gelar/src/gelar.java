/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author 12S18009 – Novita Enjelia Hutapea  
 * @author 12S18017 – Putri Yohana Panjaitan 
 * @author 12S18036 - Sandraulina Siregar 
 * @author 12S18050 - Elsa Elfransyah Marbun 
 */
import java.util.Date;
public class gelar {
    private char NIM;
    private char kode_pelanggaran;
    private Date tanggal_poin_ditambahkan; 
    private char gelar;
    
    public void update_gelar(){
     this.gelar  = gelar; 
     }
    
    public char view_gelar(){
    return gelar;
     }
}

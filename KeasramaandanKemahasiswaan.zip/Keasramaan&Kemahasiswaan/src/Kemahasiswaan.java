/**
 * @author 12S18009 – Novita Enjelia Hutapea  
 * @author 12S18017 – Putri Yohana Panjaitan 
 * @author 12S18036 - Sandraulina Siregar 
 * @author 12S18050 - Elsa Elfransyah Marbun 
 */
public class Kemahasiswaan {
  private char ID_Kemahasiswaan;
  private char nama;
  private int no_telepon;  
  private char kode_pelanggaran;
  private int bobot_pelanggaran;
  
  
  public void create_poin_pelanggaran(){
  this.bobot_pelanggaran = bobot_pelanggaran;
  }    
    
}

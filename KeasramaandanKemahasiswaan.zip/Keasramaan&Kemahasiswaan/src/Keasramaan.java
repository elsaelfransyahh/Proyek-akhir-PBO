/**
 * @author 12S18009 – Novita Enjelia Hutapea  
 * @author 12S18017 – Putri Yohana Panjaitan 
 * @author 12S18036 - Sandraulina Siregar 
 * @author 12S18050 - Elsa Elfransyah Marbun
 */
public class Keasramaan {
    public char Id_staff;
    public char Name;
    public int No_telepon; 
    public char kode_pelanggaran;
    public int bobot_pelanggaran;
    public char gelar;
    
    
public void create_poin_pelanggaran(){
     this.kode_pelanggaran  = kode_pelanggaran; 
}
public void gelar(){
    this.gelar = gelar;
}

public void addPoint(){
    this.bobot_pelanggaran = bobot_pelanggaran;
}
}
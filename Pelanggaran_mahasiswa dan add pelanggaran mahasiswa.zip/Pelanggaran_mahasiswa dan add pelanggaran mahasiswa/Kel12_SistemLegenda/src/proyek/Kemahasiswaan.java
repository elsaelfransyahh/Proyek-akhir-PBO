/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyek;

/**
 *
 * @author Jarvis
 */
public class Kemahasiswaan {
    private String Id_kemahasiswaan;
    String nama;
    String kode_pelanggaran;
    String nama_pelanggaran;
    
    public Kemahasiswaan(String _Id_kemahasiswaan, String _nama, String _kode_pelanggaran, String _nama_pelanggaran){
        this.Id_kemahasiswaan = Id_kemahasiswaan;
        this.nama = nama;
        this.kode_pelanggaran = kode_pelanggaran;
        this.nama_pelanggaran = nama_pelanggaran;
    }
    
    public void Createpoinpelanggaran(){
        this.kode_pelanggaran = kode_pelanggaran;
        this.nama_pelanggaran = nama_pelanggaran;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyek;
/**
 *
 * @author 12S18009 - Novita Enjelia Hutapea
 * @author 12S18017 - Putri Yohana Panjaitan
 * @author 12S18036 - Sandraulina Siregar
 * @author 12S18050 - Elsa Elfransyah Marbun
 */


public class Pelanggaran_mahasiswa {
    private String kode_pelanggaran;
    private String NIM;
    private String nama_pelanggaran;
    private String tanggal_update;
    private String pengurangan_poin;
    private String gelar;
    private String total_poin;
    
    
    public Pelanggaran_mahasiswa(String _kode_pelanggaran, String _NIM, String _nama_pelanggaran, String _tanggal_update, String _pengurangan_poin, String _gelar, String _total_poin){
        this.kode_pelanggaran = _kode_pelanggaran;
        this.NIM = _NIM;
        this.nama_pelanggaran = _nama_pelanggaran;
        this.tanggal_update = _tanggal_update;
        this.pengurangan_poin = _pengurangan_poin;
        this.gelar = _gelar;
        this.total_poin = _total_poin;
    }
    
    
public void insertkode_pelanggaran(){
    this.kode_pelanggaran = kode_pelanggaran;
}

public void updatekode_pelanggaran(){
    this.kode_pelanggaran = kode_pelanggaran;
}

public void insertNIM(){
    this.NIM = NIM;
}

public void updateNIM(){
    this.NIM = NIM;
}

public void insertnama_pelanggaran(){
    this.nama_pelanggaran = nama_pelanggaran;
}

public void updatenama_pelanggaran(){
    this.nama_pelanggaran = nama_pelanggaran;
}

public void inserttanggal_update(){
    this.tanggal_update = tanggal_update;
}

public void updatetanggal_update(){
    this.tanggal_update = tanggal_update;
}

public void insertpengurangan_poin(){
    this.pengurangan_poin = pengurangan_poin;
}

public void updatepengurangan_poin(){
    this.pengurangan_poin = pengurangan_poin;
}

public void insertgelar(){
    this.gelar = gelar;
}

public void updategelar(){
    this.gelar = gelar;
}

public void inserttotal_poin(){
    this.total_poin = total_poin;
}

public void updatetotal_poin(){
    this.total_poin = total_poin;
}

    void setNIM(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void settotal_poin(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}


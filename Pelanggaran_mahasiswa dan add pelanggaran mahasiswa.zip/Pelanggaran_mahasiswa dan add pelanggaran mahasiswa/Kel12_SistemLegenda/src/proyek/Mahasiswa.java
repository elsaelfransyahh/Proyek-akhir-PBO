/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyek;


/**
 *
 * @author 12S18000 - Novita Enjelia Hutapea
 * @author 12S18017 - Putri Yohana Panjaitan
 * @author 12S18036 - Sandraulina Siregar
 * @author 12S18050 - Elsa Elfransyah Marbun
 */

import java.util.Date;
public class Mahasiswa {
    public char NIM;
    public char Nama;
    public char Prodi;
    public int Angkatan;
    private char kode_pelanggaran;
    private Date tanggal_point_ditambahkan;
    private int bobot_pelanggaran;
   
public int get_pelanggaran_mahasiswa(){
    return bobot_pelanggaran;
}

public char see_poin_pelanggaran(){
    return kode_pelanggaran;
}
}

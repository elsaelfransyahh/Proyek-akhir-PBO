/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyek;

/**
 *
 * @Kelompok 12
 * @Novita - 12s18009
 * @putri - 12s18017
 * @sandraulina - 12s18036
 * @elsa - 12s18050
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import proyek.*;


public class DbHandler {
    private Connection connection;
    private boolean connected;
    public int counter;
    
    public DbHandler(){
        this.connected = false;
    }
    
    public boolean connect(String _host, String _dbName, String _username, String _password){
        String connectionString = "jdbc:mariadb://" + _host + "/" + _dbName;
        
        try{
            Class.forName("org.mariadb.jdbc.Driver");
            this.connection = DriverManager.getConnection(connectionString, _username, _password);
            this.connected = true;
         } catch (Exception _e){
             System.out.println("Exception: " + _e.getMessage());
         }
         return(this.connected);
    }
    
    public void disconnect(){
        if(this.connected){
            try{
                this.connection.close();
            } catch (Exception _e){
                System.out.println("Exception: " + _e.getMessage());
            }
        }
        this.connected = false;
        }
    
    public boolean isConnected(){
        return (this.connected);
    }
    
    public void addPoin_pelanggaran(String _kode_pelanggaran, String _nama_pelanggaran, String _pengurangan_poin, String _jenis_pelanggaran, String _tanggal_update){
        
    if(this.connected){
        String query = "INSERT INTO poin_pelanggaran(kode_pelanggaran, nama_pelanggaran, pengurangan_poin, jenis_pelanggaran, tanggal_update) VALUES(" + "" + _kode_pelanggaran + "," + "'" + _nama_pelanggaran + "',"+"" + _pengurangan_poin + "," + "" + _jenis_pelanggaran + "," + "'" + _tanggal_update + "'" + ")";
        try{
            Statement stmt = this.connection.createStatement();
            ResultSet resultSet = stmt.executeQuery(query);
        } catch (Exception _e){
            System.out.println("Exception: "+ _e.getMessage());
        }
    }
}
    public List<Poin_pelanggaran>getallpoin_pelanggaran(){
        this.counter = 0;
    List<Poin_pelanggaran> buff = new ArrayList<Poin_pelanggaran>();
        Poin_pelanggaran buf2 = null;
    if(this.connected){
     
    }
    }
    
}

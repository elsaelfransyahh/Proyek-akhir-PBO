/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyek;

/**
 *
 * @kelompok 12
 */

public class Keasramaan{
    String Id_staff;
    String nama;
    String no_telp;
    String kode_pelanggaran;
    String poin_pelanggaran;


public Keasramaan(String _Id_staff, String _nama, String _no_telp, String _kode_pelanggaran){
    this.Id_staff = Id_staff;
    this.nama = nama;
    this.no_telp = no_telp;
}
  
public void createpId_staff(){
    this.Id_staff = Id_staff;
}

public void createnama(){
    this.nama = nama;
}

public void createno_telp(){
    this.no_telp = no_telp;
}

public void createkode_pelanggaran(){
    this.kode_pelanggaran = kode_pelanggaran;
}

public void addpoin_pelanggaran(){
    this.poin_pelanggaran = poin_pelanggaran;
}
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyek;

/**
 *
 * @kelompok 12
 */
public class Gelar {
    private String gelar;
    private String NIM;
    private String total_poin;
    String prodi;
    
    public Gelar(String _gelar, String _NIM, String _total_poin, String _prodi){
        this.gelar = gelar;
        this.NIM = NIM;
        this.total_poin = total_poin;
        this.prodi = prodi;
    }
    
    public void Updategelar(){
        this.gelar = gelar;
    }
    
    public void Updatetotal_poin(){
        this.total_poin = total_poin;
    }
    
    public String viewgelar(){
        return gelar;
    }
    
    public String NIM(){
        return NIM;
    }
    
    public String total_poin(){
        return total_poin;
    }
    
    public String prodi(){
        return prodi;
    }
}
